---
name: xhs-life-rpg-maker
description: Turn a real day, mood, memory, ordinary object, or photo description into a playful RPG-style Chinese social-content package with a character card, quest, boss, loot, five-card storyboard, titles, caption, and visual prompts. Use when a creator asks to gamify everyday life, make an RPG or pixel-art post, create a humorous personalized Xiaohongshu/RedNote concept, or turn mundane experiences into a shareable visual story. Do not use for automatic posting, account operation, engagement automation, or fabricated factual claims.
---

# Turn Life into an RPG

Transform ordinary life into a specific, funny, emotionally recognizable RPG story that another person will want to share or remake.

## Gather the source material

Accept any of these inputs:

- A short description of the day or event
- A mood plus one concrete detail
- A memory, object, screenshot summary, or photo description
- Rough notes that need to become a social post

If the input is too thin to produce a personal result, ask only one question: “今天最让你记住的一个小细节是什么？” Otherwise, begin immediately. Never request account credentials or private platform data. Advise the user to remove names, phone numbers, addresses, and private chat details before sharing sensitive material.

## Find the story engine

Extract four ingredients before writing:

1. **Protagonist state** — what the person wants and how much energy they have.
2. **Concrete friction** — one observable inconvenience, conflict, or absurd detail.
3. **Emotional turn** — the moment that changes the mood, even slightly.
4. **Shareable truth** — a line that makes similar people say “这就是我”.

Prefer specific details over generic labels. “改了第 17 版标题” is useful; “工作很累” is not.

## Translate the day into RPG language

Create a coherent game metaphor rather than a random list. Use the source material to generate:

- Character name and class
- Level and current HP/MP or energy
- One passive skill grounded in a real behavior
- One humorous debuff
- Main quest and optional side quest
- Boss or obstacle
- Loot or achievement
- End-of-day system message

Keep the transformation warm and playful. Do not diagnose mental health, shame the user, or present invented events as real.

## Build the five-card post

Produce exactly five cards unless the user requests another length:

1. **Cover** — character name plus a short curiosity hook.
2. **Character card** — class, stats, skill, and debuff.
3. **Quest map** — main quest, side quest, and boss.
4. **Battle moment** — the day's most vivid scene and emotional turn.
5. **Loot screen** — achievement, system message, and a remake invitation.

Each card must include:

- On-card copy, preferably under 45 Chinese characters
- A visual composition note
- A ready-to-use image-generation prompt

Default to a charming pixel-game aesthetic with readable Chinese typography, restrained colors, and one memorable object from the source. Change the visual direction when requested.

## Package the post

After the five cards, add:

- Three title options: curiosity, resonance, and absurd-humor variants
- One natural caption of 120–220 Chinese characters
- Three to five relevant hashtags
- One low-pressure comment prompt that invites people to share their own version

Do not promise virality or use misleading claims. Avoid excessive exclamation marks, fake scarcity, forced controversy, and copied catchphrases.

## Output format

Use this structure:

```markdown
# 今日 RPG 设定

一句话概念：

## 世界观翻译
- 角色：
- 职业：
- 等级与状态：
- 被动技能：
- Debuff：
- 主线任务：
- 支线任务：
- Boss：
- 今日掉落：
- 系统消息：

## 五页图文
### 1. 封面
- 画面文字：
- 构图：
- 生图提示词：

### 2–5. ...

## 发布文案
- 标题 A｜好奇：
- 标题 B｜共鸣：
- 标题 C｜荒诞：
- 正文：
- 话题：
- 评论引导：
```

## Quality check

Before returning the result, verify that:

- At least three details come directly from the user's material.
- The character, quest, boss, and loot belong to one coherent metaphor.
- The first card is understandable within three seconds.
- The result contains one laugh and one genuine emotional beat.
- The copy is readable on a phone and avoids dense paragraphs.
- No private data, unmarked fabrication, copyrighted character imitation, or automatic platform action is included.

If a copyrighted visual style or character is requested, capture high-level traits instead of closely imitating the named creator or protected character.
